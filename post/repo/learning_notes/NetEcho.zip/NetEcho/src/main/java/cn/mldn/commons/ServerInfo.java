package cn.mldn.commons;

public interface ServerInfo {
    public static final int PORT = 6789 ;   // 定义服务器端的访问端口
    public static final String ECHO_SERVER_HOST = "localhost" ; // 要访问的远程主机名称
}
